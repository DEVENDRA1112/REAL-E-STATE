<?php
include 'session_check.php';  // Include the session check at the top
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>House Property Gallery</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="properties.css">
    <style>
        /* Additional styles for layout and modal */
        .container {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .container img {
            width: 200px;
            margin: 10px;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .container img:hover {
            transform: scale(1.05);
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
        }
        .modal img {
            max-width: 90%;
            max-height: 90%;
        }
        .close {
            position: absolute;
            top: 20px;
            right: 30px;
            color: #fff;
            font-size: 35px;
            font-weight: bold;
            cursor: pointer;
        }
        .filter {
            margin: 20px 0;
        }
        .property-details {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .property-details img {
            max-width: 80%;
            margin-bottom: 20px;
        }
        .tx{
            color:black;
        }
    </style>  
</head>
<body>
    
<header class="header">
    <a href="#" class="logo">Real Estate</a>
    <nav class="nav-items">
        <a href='index.php'>Home</a>
        <a href='4th.php'>Properties-Area_price</a>
        <a href='fifth.php'>Reviews</a>
        <div class="filter">
            <label for="search" class="tx">Search by location:</label>
            <input type="text" id="search" oninput="filterProperties()" placeholder="Type a city name...">
        </div>
        <div class="filter">
            <label for="sort" class="tx">Sort by:</label>
            <select id="sort" onchange="sortProperties()">
                <option value="location">Location</option>
                <option value="price">Price</option>
            </select>
        </div>
        <!-- Check if the user is logged in -->
        <?php if (isset($_SESSION['username'])): ?>
            <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
            <a href="logout.php">Log Out</a>
        <?php else: ?>
            <a href="signup.php">Sign Up</a>
            <a href="loginpage.php">Sign In</a>
        <?php endif; ?>
    </nav>
</header>

<main>
    <h1>House Properties</h1>
    
    <div class="container" data-location="Junagadh" data-price="300000">
        <h2>Junagadh House Property</h2>
        <div class="content">
            <p>Welcome to the Junagadh House gallery. This house is a beautiful blend of traditional and modern architecture.</p>
        </div>
        <img src="PICS/pexels-julia-kuzenkov-442028-1974596.jpg" alt="Junagadh House - Exterior View 1" onclick="showDetails('Junagadh House', 'Beautiful blend of traditional and modern architecture.', '$300,000', this.src)">
        <img src="PICS/image15.jpg" alt="Junagadh House - Living Room" onclick="showDetails('Junagadh House', 'Spacious living room with modern amenities.', '$300,000', this.src )">
        <img src="PICS/image14.jpg" alt="Junagadh House - Kitchen" onclick="showDetails('Junagadh House', 'Modern kitchen with all appliances.', '$300,000', this.src)">
        <img src="PICS/image19.jpg" alt="Junagadh House - Garden View" onclick="showDetails('Junagadh House', 'Beautiful garden view.', '$300,000', this.src)">
        <img src="PICS/image12.jpg" alt="Junagadh House - Bedroom" onclick="showDetails('Junagadh House', 'Cozy bedroom with ample space.', '$300,000', this.src)">    
    </div>

    <div class="container" data-location="Rajkot" data-price="400000">
        <h2>Rajkot House Property</h2>
        <div class="content">
            <p>Welcome to the Rajkot House gallery. This house is a beautiful blend of traditional and modern architecture.</p>
        </div>
        <img src="PICS/WhatsApp Image 2024-07-19 at 23.08.58_6efa1544.jpg" alt="Rajkot House - Exterior View 1" onclick="showDetails('Rajkot House', 'Luxurious house with modern design.', '$400,000', this.src)">
        <img src="PICS/OIP (2).jpeg" alt="Rajkot House - Living Room" onclick="showDetails('Rajkot House', 'Elegant living room with stylish decor.', '$400,000', this.src)">
        <img src="PICS/OIP.jpeg" alt="Rajkot House - Dining Area" onclick="showDetails('Rajkot House', 'Spacious dining area for family gatherings.', '$400,000', this.src)">
        <img src="PICS/image19.jpg" alt="Rajkot House - Garden View" onclick="showDetails('Rajkot House', 'Beautiful garden view.', '$300,000', this.src)">
        <img src="PICS/image20.jpg" alt="Rajkot House - Backyard" onclick="showDetails('Rajkot House', 'Beautiful backyard for relaxation.', '$400,000', this.src)">    
    </div>

    <div class="container" data-location="Ahmedabad" data-price="350000">
        <h2>Ahmedabad House Property</h2>
        <div class="content">
            <p>Welcome to the Ahmedabad House gallery. This house is a beautiful blend of traditional and modern architecture.</p>
        </div>
        <img src="PICS/pexels-pixabay-53610.jpg" alt="Ahmedabad House - Exterior View 1" onclick="showDetails('Ahmedabad House', 'Charming house with a lovely garden.', '$350,000', this.src)">
        <img src="PICS/OIP (10).jpeg" alt="Ahmedabad House - Living Room" onclick="showDetails('Ahmedabad House', 'Stylish living room with modern furnishings.', '$350,000', this.src)">
        <img src="PICS/OIP (8).jpeg" alt="Ahmedabad House - Bedroom" onclick="showDetails('Ahmedabad House', 'Spacious bedroom with natural light.', '$350,000', this.src)">
        <img src="PICS/OIP (7).jpeg" alt="Ahmedabad House - Garden" onclick="showDetails('Ahmedabad House', 'Beautiful garden area.', '$350,000', this.src)">
        <img src="PICS/OIP (5).jpeg" alt="Ahmedabad House - Kitchen" onclick="showDetails('Ahmedabad House', 'Modern kitchen with all amenities.', '$350,000', this.src)">    
    </div>

    <div class="container" data-location="Baroda" data-price="320000">
        <h2>Baroda House Property</h2>
        <div class="content">
            <p>Welcome to the Baroda House gallery. This house is a beautiful blend of traditional and modern architecture.</p>
        </div>
        <img src="PICS/pexels-expect-best-79873-323780.jpg" alt="Baroda House - Exterior View 1" onclick="showDetails('Baroda House', 'Stunning exterior with a modern touch.', '$320,000', this.src)">
        <img src="PICS/pexels-heyho-6434622.jpg" alt="Baroda House - Living Room" onclick="showDetails('Baroda House', 'Cozy living room with elegant decor.', '$320,000', this.src)">
        <img src="PICS/pexels-vika-glitter-392079-1648776.jpg" alt="Baroda House - Bedroom" onclick="showDetails('Baroda House', 'Spacious bedroom with a serene atmosphere.', '$320,000', this.src)">
        <img src="PICS/pexels-vika-glitter-392079-1648771.jpg" alt="Baroda House - Dining Area" onclick="showDetails('Baroda House', 'Inviting dining area for family meals.', '$320,000', this.src)">
        <img src="PICS/pexels-jvdm-1457842.jpg" alt="Baroda House - Garden" onclick="showDetails('Baroda House', 'Lush garden perfect for relaxation.', '$320,000', this.src)">    
    </div>

    <!-- Property Details Modal -->
    <div class="property-details" id="property-details" style="display:none;">
        <span class="close" onclick="closeDetails()">&times;</span>
        <h2 id="property-title"></h2>
        <p id="property-description"></p>
        <img id="property-image" src="" alt="Property Image">
        <p id="property-price"></p>
    </div>
</main>

<script>
    function showDetails(title, description, price, image) {
        document.getElementById("property-title").innerText = title;
        document.getElementById("property-description").innerText = description;
        document.getElementById("property-price").innerText = price;
        document.getElementById("property-image").src = image;
        document.getElementById("property-details").style.display = "block";
    }

    function closeDetails() {
        document.getElementById("property-details").style.display = "none";
    }

    function filterProperties() {
        const searchValue = document.getElementById("search").value.toLowerCase();
        const containers = document.querySelectorAll('.container');

        let firstVisibleContainer = null; // Track the first visible container

        containers.forEach(container => {
            const location = container.getAttribute('data-location').toLowerCase();
            if (location.includes(searchValue)) {
                container.style.display = 'block'; // Show the container
                if (!firstVisibleContainer) {
                    firstVisibleContainer = container; // Set the first visible container
                }
            } else {
                container.style.display = 'none'; // Hide the container
            }
        });

        // Scroll to the first visible container, if any
        if (firstVisibleContainer) {
            firstVisibleContainer.scrollIntoView({ behavior: 'smooth' });
        }
    }

    function sortProperties() {
        const sortValue = document.getElementById("sort").value;
        const containers = Array.from(document.querySelectorAll('.container'));

        containers.sort((a, b) => {
            if (sortValue === "location") {
                return a.getAttribute('data-location').localeCompare(b.getAttribute('data-location'));
            } else if (sortValue === "price") {
                return parseFloat(a.getAttribute('data-price')) - parseFloat(b.getAttribute('data-price'));
            }
        });

        const main = document.querySelector('main');
        containers.forEach(container => main.appendChild(container)); // Re-append sorted containers
    }
</script>
</body>
</html>