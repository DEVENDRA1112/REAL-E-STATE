<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "real_estate");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        header("Location: loginpage.php"); // Redirect to login after successful signup
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="signup.css">
    <script>
        function validateForm() {
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Validate username
            if (username.length < 3) {
                alert("Username must be at least 3 characters long.");
                return false;
            }

            // Validate email
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Validate password
            if (password.length < 6) {
                alert("Password must be at least 6 characters long.");
                return false;
            }

            // If all validations pass
            return true;
        }
    </script>
</head>
<body>

<form action="signup.php" method="POST" class="signup-form" onsubmit="return validateForm()">
    <h2>Create an Account</h2>
    
    <label for="username">Username</label>
    <input type="text" id="username" name="username">
    
    <label for="email">Email</label>
    <input type="email" id="email" name="email" >
    
    <label for="password">Password</label>
    <input type="password" id="password" name="password" >
    
    <button type="submit">Sign Up</button>
</form>

</body>
</html>
