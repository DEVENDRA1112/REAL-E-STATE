<?php

include 'session_check.php'; // Ensure the user is logged in



// Database connection

$servername = "localhost";

$username = "root";

$password = "";

$dbname = "real_estate";



// Create connection

$conn = new mysqli($servername, $username, $password, $dbname);



// Check connection

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}



// Check if the property_id is set in the URL

if (isset($_GET['property_id'])) {

    $property_id = $_GET['property_id'];



    // Fetch property details from the database

    $sql = "SELECT * FROM properties_add WHERE id = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $property_id);

    $stmt->execute();

    $result = $stmt->get_result();

    $property = $result->fetch_assoc();



    if (!$property) {

        echo "<p>Property not found.</p>";

        exit;

    }

} else {

    echo "<p>No property selected for booking.</p>";

    exit;

}



// Close the database connection

$conn->close();



// Handle the booking form submission

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get the user's booking details

    $user_id = $_SESSION['user_id'];  // Assuming user_id is stored in the session

    $property_id = $_POST['property_id'];

    $user_name = $_SESSION['username'];  // Assuming the username is stored in the session

    $booking_date = date('Y-m-d H:i:s');



    // Save the booking in the database (example)

    $conn = new mysqli($servername, $username, $password, $dbname);

    $sql = "INSERT INTO bookings (user_id, property_id, user_name, booking_date) VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("iiss", $user_id, $property_id, $user_name, $booking_date);

    $stmt->execute();



    // Close the connection

    $conn->close();



    // Redirect to a confirmation page or display a message

    echo "<script>

            alert('Booking confirmed! You will be redirected shortly.');

            window.location.href = '4th.php';

          </script>";

    exit;

}

?>



<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Book Property</title>

    <link rel="stylesheet" href="4th.css">

    <style>

        .booking-container {

            display: flex;

            flex-direction: column;

            align-items: center;

            margin-top: 50px;

        }



        .property-details {

            width: 60%;

            background-color: #f9f9f9;

            padding: 20px;

            border-radius: 8px;

            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);

            margin-bottom: 30px;

        }



        .property-details img {

            width: 100%;

            height: auto;

            border-radius: 8px;

        }



        .property-details h2 {

            margin-top: 20px;

            font-size: 24px;

            font-weight: bold;

        }



        .property-details p {

            margin: 10px 0;

            font-size: 16px;

        }



        .book-btn {

            background-color: #4CAF50;

            color: white;

            padding: 10px 20px;

            border: none;

            cursor: pointer;

            border-radius: 5px;

            font-size: 18px;

        }



        .book-btn:hover {

            background-color: #45a049;

        }

    </style>

</head>

<body>



<header class="header">

    <a href="#" class="logo">Real Estate</a>

    <nav class="nav-items">

      <a href='index.php'>Home</a>

      <a href='properties.php'>Properties</a>

      <a href='fifth.php'>Reviews</a>

      

        <!-- Check if the user is logged in -->

        <?php if (isset($_SESSION['username'])): ?>

            <a href="profile.php"><?php echo $_SESSION['username']; ?></a>

            <a href="logout.php">Log Out</a>

        <?php else: ?>

            <a href="signup.php">Sign Up</a>

            <a href="loginpage.php">Sign In</a>

        <?php endif; ?>

    </nav>

</header>



<main class="booking-container">

    <div class="property-details">

        <img src="<?php echo $property['photo']; ?>" alt="<?php echo $property['name']; ?>">

        <h2><?php echo $property['name']; ?></h2>

        <p>Location: <?php echo $property['address']; ?></p>

        <p>Price: ₹<?php echo number_format($property['price']); ?></p>

        <!-- <p>Description: <?php echo $property['description']; ?></p> -->

    </div>



    <form method="POST" action="">

        <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">

        <button type="submit" class="book-btn" onclick="return confirm('Confirm booking?')">Confirm Booking</button>

    </form>

</main>



<footer>

    <p>&copy; 2024 Real Estate Shopping. All rights reserved.</p>

</footer>



</body>

</html>