<?php
// Start the session and output buffering
session_start();
ob_start();  // Start output buffering

// Connect to the database (update with your credentials)
$conn = new mysqli('localhost', 'root', '', 'real_estate');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize form inputs
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $contact = filter_input(INPUT_POST, 'contact', FILTER_SANITIZE_STRING);
    $city = filter_input(INPUT_POST, 'city', FILTER_SANITIZE_STRING);
    $review = filter_input(INPUT_POST, 'review', FILTER_SANITIZE_STRING);
    $rating = filter_input(INPUT_POST, 'rating', FILTER_VALIDATE_INT);

    // Validate contact (ensure it's numeric and 10 digits)
    if (!preg_match("/^[0-9]{10}$/", $contact)) {
        $_SESSION['message'] = "Please enter a valid 10-digit contact number.";
        header("Location: submit_review.php?error=invalid_contact");
        exit;
    } else {
        // Prepare and bind SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO reviews (name, contact, city, review, rating, date) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssssi", $name, $contact, $city, $review, $rating);

        // Execute the statement and check for success
        if ($stmt->execute()) {
            $_SESSION['message'] = "Your review has been submitted successfully.";
            header("Location: fifth.php");
            echo "Successfully added your review.Thank You!";
            exit;
        } else {
            $_SESSION['message'] = "Error: " . $stmt->error;
            header("Location: submit_review.php?error=db_error");
            exit;
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the connection
$conn->close();

ob_end_flush();  // Send output and end buffering
?>