<?php
$conn = new mysqli("localhost", "root", "", "real_estate");

// Check the connection
if ($conn->connect_error) {
    echo "<script>alert('Cannot connect to the database: " . $conn->connect_error . "');</script>";
    exit();
}
?>
