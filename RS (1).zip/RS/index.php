<?php
require('conection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Real Estate HomePage</title>
  <link rel="stylesheet" href="homepage.css">
  <script>
    function validateForm() {
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const message = document.getElementById('message').value.trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      // Validate name
      if (name === "") {
        alert("Please enter your name.");
        return false;
      }

      // Validate email
      if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
      }

      // Validate message
      if (message === "") {
        alert("Please enter your message.");
        return false;
      }

      // If all validations pass
      return true;
    }
  </script>
</head>

<body>

  <!-- Header -->
  <header class="header">
    <div>
      <a href="#" class="logo">Real Estate</a>
    </div>
    <nav class="nav-items">
      <a href='index.php'>Home</a>
      <a href="#properties">Properties</a>
      
      <a href="#contact">Contact</a>
      <a href='4th.php'>Properties-Area_price</a>
      <a href='fifth.php'>Reviews</a>
      <?php if (isset($_SESSION['username'])): ?>
        <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
        <a href="logout.php">Log Out</a>
      <?php else: ?>
        <div id="user-btn" class="fas fa-user">
          <a href="loginpage.php">Sign In</a>
        </div>
      <?php endif; ?>
    </nav>
  </header>

  <!-- Main Content -->
  <main>
    <section class="intro" id="home">
      <h1>Find Your Dream Home</h1>
      <p>We help you find the best property deals</p>
      <button><a href='properties.php'>Get Started</a></button>
    </section>

    <section class="property-listing" id="properties">
      <div class="property-container">
        <img src="https://th.bing.com/th/id/OIP.-R0RrcfyXBRrtMmIxgSXywHaE8?w=305&h=203&c=7&r=0&o=5&dpr=1.4&pid=1.7" alt="Luxury Apartment">
        <div class="property-info">
          <h3>Luxury Apartment</h3>
          <p>2 Bed, 2 Bath in the city center</p>
        </div>
      </div>

      <div class="property-container">
        <img src="PICS/OIP%20(11).jpeg" alt="Modern House 2">
        <div class="property-info">
          <h3>Modern House</h3>
          <p>4 Bed, 3 Bath with a beautiful garden</p>
        </div>
      </div>

      <div class="property-container">
        <img src="PICS/image20.jpg" alt="Beachfront Villa">
        <div class="property-info">
          <h3>Beachfront Villa</h3>
          <p>3 Bed, 2 Bath with a sea view</p>
        </div>
      </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contact">
      <div class="contact-text">
        <h2>Feed Back</h2>
        <p>Have questions or need more information? Feel free to reach out to us!</p>
      </div>
      <form onsubmit="return validateForm()">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Message</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <button type="submit">Send Message</button>
      </form>
    </section>
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <div class="links">
        <span>Contact Us</span>
        <p>123 Main Street, Anytown, USA</p>
        <p>Email: info@realestate.com</p>
        <p>Phone: +1 (555) 123-4567</p>
      </div>
      <div class="links">
        <span>Follow Us</span>
        <a href="https://m.facebook.com/devendra.odedra.37"><i class="fab fa-facebook"></i> Facebook</a>
        <a href="https://in.linkedin.com/in/devendra-odedra-8a1a81313"><i class="fab fa-twitter"></i> Twitter</a>
        <a href="https://www.instagram.com/devendra__odedra/"><i class="fab fa-instagram"></i> Instagram</a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2024 Real Estate. All rights reserved.</p>
    </div>
  </footer>

</body>

</html>
