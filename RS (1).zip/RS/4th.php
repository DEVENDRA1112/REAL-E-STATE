<?php
include 'session_check.php';  // Include the session check at the top

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "real_estate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all properties from the database
$sql = "SELECT * FROM properties_add";
$result = $conn->query($sql);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real Estate Shopping</title>
    <link rel="stylesheet" href="4th.css">
    <style>
        /* Container for all properties */
        .property-list {
            display: flex;
            flex-wrap: wrap; /* Allows wrapping of properties to the next line */
            justify-content: space-between; /* Spacing between properties */
            gap: 20px; /* Space between items */
        }

        /* Each property card */
        .property {
            width: calc(25.33% - 20px); /* Set each property to take 1/3 of the row width */
            box-sizing: border-box; /* Ensure padding/margins do not overflow */
            background-color: #f4f4f4;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .property img {
            width: 100%; /* Make image take full width of the card */
            height: auto;
            border-radius: 8px;
        }

        .property h2 {
            margin-top: 10px;
            font-size: 18px;
            font-weight: bold;
        }

        .property p {
            margin: 5px 0;
        }

/* Styling for the Book Now button */
.book-btn {
    background-color: #4CAF50;  /* Green background */
    color: white;  /* White text color */
    padding: 10px 20px;  /* Padding around the text */
    border: none;  /* No border */
    cursor: pointer;  /* Pointer cursor when hovering */
    margin-top: 10px;  /* Spacing from the previous element */
    margin-left: 10px;
    border-radius: 5px;  /* Rounded corners */
    font-size: 18px;  /* Font size */
    text-decoration: none;  /* Remove underline */
    display: inline-block;  /* Make it behave like a block-level element */
    transition: background-color 0.3s ease, transform 0.3s ease;  /* Smooth transition */
}

.book-btn:hover {
    background-color: #45a049;  /* Darker green on hover */
    transform: scale(1.05);  /* Slightly increase the size when hovered */
}

.book-btn:focus {
    outline: none;  /* Remove default focus outline */
}

        /* Media query for tablet-sized screens */
        @media (max-width: 1024px) {
            .property {
                width: calc(50% - 20px); /* On smaller screens, show two properties per row */
            }
        }

        /* Media query for mobile-sized screens */
        @media (max-width: 768px) {
            .property {
                width: 100%; /* On very small screens, show one property per row */
            }
        }
    </style>
</head>
<body>
<header class="header">
    <a href="#" class="logo">Real Estate</a>
    <nav class="nav-items">
      <a href='index.php'>Home</a>
      <a href='properties.php'>Properties</a>
      <a href='fifth.php'>Reviews</a>
     
        <!-- Check if the user is logged in -->
        <?php if (isset($_SESSION['username'])): ?>
            <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
            <a href="logout.php">Log Out</a>
        <?php else: ?>
            <a href="signup.php">Sign Up</a>
            <a href="loginpage.php">Sign In</a>
        <?php endif; ?>
    </nav>
</header>

<main>
    <section class="property-list">
        <?php
        // Check if there are properties in the database
        if ($result->num_rows > 0) {
            // Loop through all the properties and display them
            while ($row = $result->fetch_assoc()) {
                echo "<div class='property'>";
                // Use the actual photo path from the database if available, otherwise, use a placeholder
                $photoPath = !empty($row['photo']) ? $row['photo'] : 'default.jpg';
                echo "<img src='$photoPath' alt='" . $row['name'] . "'>";
                echo "<h2>" . $row['name'] . "</h2>";
                echo "<p>Location: " . $row['address'] . "</p>";
                echo "<p>Price: ₹" . number_format($row['price']) . "</p>";

                // Example agent info
                // You can change these values for each property if you want different details
                $agentName = 'John Doe';
                $agentPhone = '+91 9876543210';
                $agentEmail = 'johndoe@example.com';

                // Display the contact button with example agent info
                echo "<button class='contact-btn' onclick='alert(\"Agent: $agentName, Phone: $agentPhone, Email: $agentEmail\")'>Contact Agent</button>";

                // Add the "Book Now" button
                echo "<a href='book_property.php?property_id=" . $row['id'] . "' class='book-btn'>Book Now</a>";

                echo "</div>";
            }
        } else {
            echo "<p>No properties found.</p>";
        }
        ?>
    </section>
</main>

<footer>
    <p>&copy; 2024 Real Estate Shopping. All rights reserved.</p>
</footer>

</body>
</html>