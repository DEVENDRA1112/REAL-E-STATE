<?php
include 'session_check.php';  // Include the session check at the top
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Reviews</title>
<style>

    
/* General Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    color: #333;
    padding-top: 70px; /* Make space for fixed header */
    margin: 0;
}

/* Header Styles */
 /* CSS for header */
 .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px 20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    animation: fadeIn 1s ease-in;
    z-index: 10;
    position: fixed;
    width: 100%;
    top: 0;
  }

  .header .logo {
    font-size: 25px;
    font-family: 'Sriracha', cursive;
    color: #000;
    text-decoration: none;
  }

  .nav-items {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }

  .nav-items a {
    text-decoration: none;
    color: #000;
    padding: 10px 20px;
    text-transform: uppercase;
    font-weight: bold;
    transition: background-color 0.3s, color 0.3s;
  }

  .nav-items a:hover {
    background-color: rgba(0, 0, 0, 0.2);
    color: #333;
  }


/* Add Review Section */
.add-review {
    background-color: white;
    max-width: 600px;
    margin: 30px auto;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.add-review h2 {
    text-align: center;
    color: #34495e;
    margin-bottom: 20px;
}

/* Form Styles */
form {
    display: flex;
    flex-direction: column;
}

form div {
    margin-bottom: 20px;
}

form label {
    font-weight: bold;
    margin-bottom: 5px;
    color: #34495e;
}

form input,
form select,
form textarea {
    width: 100%;
    padding: 12px;
    border: 2px solid #bdc3c7;
    border-radius: 5px;
    font-size: 16px;
    color: #333;
    transition: border-color 0.3s;
}

form input:focus,
form select:focus,
form textarea:focus {
    border-color: #f39c12;
    outline: none;
}

form textarea {
    height: 100px;
    resize: none;
}

/* Submit Button */
button[type="submit"] {
    background-color: #34495e;
    color: white;
    padding: 12px;
    font-size: 18px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button[type="submit"]:hover {
    background-color: #f39c12;
}

/* Reviews Section */
.reviews-section {
    max-width: 800px;
    margin: 30px auto;
    padding: 30px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.reviews-section h2 {
    text-align: center;
    color: #34495e;
    margin-bottom: 20px;
}

/* Individual Review Styles */
.review {
    margin-bottom: 20px;
    padding: 15px;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    transition: box-shadow 0.3s;
}

.review:hover {
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.review-header {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

.review-header img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-right: 15px;
}

.reviewer-info h3 {
    margin: 0;
    font-size: 18px;
    color: #34495e;
}

.reviewer-info p {
    margin: 5px 0;
    font-size: 14px;
    color: #777;
}

.review-content {
    display: none;
    margin-top: 10px;
}

.rating span {
    font-size: 18px;
    color: #f39c12;
}

/* Toggle Button */
.toggle-button {
    background-color: #34495e;
    color: white;
    border: none;
    padding: 8px 12px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.toggle-button:hover {
    background-color: #f39c12;
}

/* Responsive Styles */
@media (max-width: 600px) {
    .header {
        flex-direction: column;
        align-items: flex-start;
    }

    .nav-items {
        margin-top: 10px;
    }

    .add-review, .reviews-section {
        margin: 10px;
        padding: 20px;
    }
}

    </style>
</head>

<body>

<header class="header">
    <a href="#" class="logo">Real Estate</a>
    <nav class="nav-items">
        <a href='index.php'>Home</a>
        <a href='properties.php'>Properties</a>
        <a href='4th.php'>Properties-Area Price</a>
        <a href='fifth.php'>Reviews</a>
        <?php if (isset($_SESSION['username'])): ?>
            <a href="profile.php"><?php echo $_SESSION['username']; ?></a>
            <a href="logout.php">Log Out</a>
        <?php else: ?>
            <a href="signup.php">Sign Up</a>
            <a href="loginpage.php">Sign In</a>
        <?php endif; ?>
    </nav>
</header>

<!-- Add a Review Section -->
<div class="add-review">
    <h2>Add a Review</h2>
    <form action="submit_review.php" method="POST">
        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div>
            <label for="contact">Contact:</label>
            <input type="text" id="contact" name="contact" required>
        </div>
        <div>
            <label for="city">City:</label>
            <select id="city" name="city" required>
                <option value="Rajkot">Rajkot</option>
                <option value="Surat">Surat</option>
                <option value="Ahmedabad">Ahmedabad</option>
            </select>
        </div>
        <div>
            <label for="review">Review:</label>
            <textarea id="review" name="review" required></textarea>
        </div>
        <div>
            <label for="rating">Rating:</label>
            <select id="rating" name="rating" required>
                <option value="5">★★★★★</option>
                <option value="4">★★★★</option>
                <option value="3">★★★</option>
                <option value="2">★★</option>
                <option value="1">★</option>
            </select>
        </div>
        <button type="submit">Submit Review</button>
    </form>
</div>

<!-- User Reviews Section -->
<div class="reviews-section">
    <h2>User Reviews</h2>
    <div class="review-list">
        <?php
        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'real_estate');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch reviews
        $stmt = $conn->prepare("SELECT * FROM reviews ORDER BY date DESC");
        $stmt->execute();
        $result = $stmt->get_result();

        // Display reviews
        while ($review = $result->fetch_assoc()) {
        ?>
            <div class="review">
                <div class="review-header">
                    <img src="https://th.bing.com/th/id/OIP.4Sf5Qzlwrq-0iNoydcGW0wHaLH?w=183&h=274&c=7&r=0&o=5&dpr=1.4&pid=1.7" alt="<?php echo $review['name']; ?>">
                    <div class="reviewer-info">
                        <h3><?php echo htmlspecialchars($review['name']); ?></h3>
                        <p>Contact: <?php echo htmlspecialchars($review['contact']); ?> | Date: <?php echo htmlspecialchars($review['date']); ?></p>
                    </div>
                </div>
                <div class="review-content">
                    <p><?php echo htmlspecialchars($review['review']); ?></p>
                    <div class="rating">
                        <span><?php echo str_repeat('★', intval($review['rating'])); ?></span>
                    </div>
                </div>
                <button class="toggle-button">Show Review</button>
            </div>
        <?php
        }

        // Close the connection
        $stmt->close();
        $conn->close();
        ?>
    </div>
</div>

<!-- JavaScript to toggle reviews -->
<script>
    document.querySelectorAll('.toggle-button').forEach(button => {
        button.addEventListener('click', () => {
            const reviewContent = button.parentElement.querySelector('.review-content');
            const isVisible = reviewContent.style.display === 'block';
            reviewContent.style.display = isVisible ? 'none' : 'block';
            button.textContent = isVisible ? 'Show Review' : 'Hide Review';
        });
    });
</script>

</body>
</html>
