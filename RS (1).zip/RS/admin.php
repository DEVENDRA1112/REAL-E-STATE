<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "real_estate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle deletion of property
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Fetch the photo path from the database to delete the image file
    $sql = "SELECT photo FROM properties_add WHERE id = $delete_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $photoPath = $row['photo'];

        // Delete the photo from the server if it exists
        if (file_exists($photoPath)) {
            unlink($photoPath);  // Delete the file from the server
        }

        // Now delete the record from the database
        $sql = "DELETE FROM properties_add WHERE id = $delete_id";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Property deleted successfully!');</script>";
        } else {
            echo "<script>alert('Error deleting property: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('No such property found.');</script>";
    }
}

// If the form is submitted (POST request) for adding a new property
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['propertyID'];  // Get the ID from the form
    $price = $_POST['propertyPrice']; // Get the price from the form
    $name = $_POST['propertyName'];
    $address = $_POST['propertyAddress'];

    // Handle file upload
    $photo = $_FILES['propertyPhoto'];

    // Define the target directory where photos will be stored
    $target_dir = "PICS/";  // Folder where images will be uploaded
    $target_file = $target_dir . basename($photo["name"]); // Complete file path

    // Get the file extension (e.g., jpg, jpeg, png)
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $allowed_types = array("jpg", "jpeg", "png", "gif"); // Allowed file types

    // Check if the uploaded file is an image
    if (in_array($imageFileType, $allowed_types)) {
        // Try to upload the file to the target directory
        if (move_uploaded_file($photo["tmp_name"], $target_file)) {
            $photoPath = $target_file; // Store the photo file path

            // Insert the property details into the database
            $sql = "INSERT INTO properties_add (id, name ,price , address, photo) VALUES ('$id', '$name', '$price', '$address', '$photoPath')";
            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('New property added successfully!');</script>";
            } else {
                echo "<script>alert('Error adding property: " . $conn->error . "');</script>";
            }
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    } else {
        echo "<script>alert('Sorry, only JPG, JPEG, PNG, & GIF files are allowed.');</script>";
    }
}

// Fetch all properties from the database
$sql = "SELECT * FROM properties_add";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Property</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<header class="header">
    <a href="" class="logo">Real Estate</a>
    <nav class="nav-items">
        <a href="logout.php" class="logout-btn">Log Out</a>
    </nav>
</header>

<div class="container">
    <h2>Add New Property</h2>
    <form action="admin.php" method="POST" enctype="multipart/form-data">
        <label for="propertyID">Property ID:</label>
        <input type="number" id="propertyID" name="propertyID" required><br><br>

        <label for="propertyName">Property Name:</label>
        <input type="text" id="propertyName" name="propertyName" required><br><br>

        <label for="propertyPrice">Property Price:</label>
        <input type="Number" id="propertyPrice" name="propertyPrice" required><br><br>

        <label for="propertyAddress">Property Address:</label>
        <input type="text" id="propertyAddress" name="propertyAddress" required><br><br>

        <label for="propertyPhoto">Property Photo:</label>
        <input type="file" id="propertyPhoto" name="propertyPhoto" required><br><br>

        <button type="submit">Add Property</button>
    </form>

    <div class="properties-list">
        <h2>Properties</h2>
        <?php
        // Check if there are any properties in the database
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='property-item'>";
                echo "<h3>" . $row['name'] . "</h3>";
                echo "<p>Price: " . $row['price'] . "</p>";  //<!-- Display Price -->
                echo "<p>Address: " . $row['address'] . "</p>";
                if (!empty($row['photo'])) {
                    echo "<img src='" . $row['photo'] . "' alt='" . $row['name'] . "' width='200'>";
                } else {
                    echo "<p>No photo available</p>";
                }
                // Delete button
                echo "<a href='?delete_id=" . $row['id'] . "' class='delete-button'>Delete</a>";
                echo "</div><hr>";
            }
        } else {
            echo "<p>No properties found.</p>";
        }
        ?>
    </div>
</div>

</body>
</html>
