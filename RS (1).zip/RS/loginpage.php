<?php
session_start();

// Connect to the database
$conn = new mysqli("localhost", "root", "", "real_estate");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check for admin login
    $adminEmail = "admin@example.com";  // Hardcoded admin email
    $adminPassword = "admin123";  // Hardcoded admin password

    if ($email === $adminEmail && $password === $adminPassword) {
        // Admin login
        $_SESSION['user_id'] = 1;  // Admin user ID
        $_SESSION['username'] = "Admin";  // Admin username
        header("Location: admin.php");  // Redirect to admin panel
        exit();
    } else {
        // Check for normal user login
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Verify the password
            if (password_verify($password, $user['password'])) {
                // Store user information in session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];

                // Redirect to homepage (user dashboard)
                header("Location: index.php");
                exit();
            } else {
                echo "Incorrect password";
            }
        } else {
            echo "User not found";
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="loginpage.css">
    <script>
        function validateForm() {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Validate email
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Validate password
            if (password.trim() === "") {
                alert("Password cannot be empty.");
                return false;
            }

            // If all validations pass
            return true;
        }
    </script>
</head>
<body>
    <form action="loginpage.php" method="POST" onsubmit="return validateForm()">
        <label for="email">Email</label>
        <input type="email" id="email" name="email">
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password">

        <div>
            <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
        </div>
        <button type="submit">Sign In</button>
    </form>
</body>
</html>
